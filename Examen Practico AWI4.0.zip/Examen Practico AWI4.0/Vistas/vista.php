<!DOCTYPE html>
<html lang="en">
<head>
	<body bgcolor="black">

	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="../css/style.css">
	<title>Modelo Vista Controlador</title>
	</body>
<script>
	
	function eliminar(id)
	{
		if(confirm("¿ Estas seguro de eliminar el registro ?"))
		{
			window.location = "../Controlador/controlador.php?ideliminar=" + id;
		}
	}

	function modificar(id)
	{
		window.location = "../Controlador/controlador.php?idmodificar=" + id;
	}
</script>

</head>

<table class="table table-bordered table-sm" cellspacing="0" width="100%">
<header class="bg-info bg-gradient text-white">
            <div class="container px-4 text-center">
<center>
<h1>Categorias Registro</h1>
	<form action="../Controlador/controlador.php" id="frminsertar" name="frminsertar" method="post">
		<!-- <label for="">Numero: </label> -->
		<input type="text" id="txtid" name="txtid" value="<?php echo @$buscar_mod[0][0]; ?>" hidden>
		<br>
		<br>
		<label for="">Nombre</label>
		<input type="text" id="txtnombre" name="txtnombre" placeholder="Nombre" value="<?php echo @$buscar_mod[0][1]; ?>" >
		<br>
		<br>
		<label for="">Fecha</label>
		<input type="date" id="txtfecha" name="txtfecha" value="<?php echo @$buscar_mod[0][2]; ?>" >
		<br>
		<br>
		<input type="submit" id="btninsertar" name="btninsertar" value="<?php if(isset($_GET['idmodificar']))
		{ 
			echo 'Modificar';
		}
		else
		{
			echo 'Insertar';
		}
		 ?>">
	</form>
	</center>
	<br><br>
	<center>
	<form action="../Controlador/controlador.php" id="frmbuscar" name="frmbuscar" method="post">
		<label for="">Buscar</label>
		<input type="text" id="txtbuscar" name="txtbuscar" placeholder="Buscar nombre">
		<input type="submit" id="btnbuscar" name="btnbuscar" value="Buscar" >
		<br><br>
		<table align="center"  style="">
			<tr>
				<td align="center" >Número</td>
				<td align="center" >Nombre</td>
				<td align="center" >Fecha</td>
				<td colspan="2" align="center">Accion</td>
			</tr>
			<?php echo $datos; ?>
		</table>
	</form>
	
	</center>
</body>
</html>