<?php 

define('DB_SERVER', 'localhost');
define('DB_NAME', 'aw2022');
define('DB_USER', 'root');
define('DB_PASS', '');

 ?>